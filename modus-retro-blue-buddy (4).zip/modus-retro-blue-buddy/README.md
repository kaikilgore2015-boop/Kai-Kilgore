# Modus Retro — Blue Buddy

A beginner-friendly local web app with an animated blue face, browser speech recognition, spoken replies, an AI personality, and editable memory notes.

## What you need

- A computer with Node.js installed (LTS version recommended)
- An OpenAI API key with API access enabled
- A modern browser; Chrome is recommended for speech recognition

**Important:** API usage can cost money. Check your API billing/usage settings. ChatGPT subscriptions and API billing are separate. Keep your API key private and never paste it into `public/index.html`.

## Setup

1. Install Node.js from https://nodejs.org if it isn't already installed.
2. Unzip this folder somewhere you can find it.
3. Open a terminal/command prompt inside the `modus-retro-blue-buddy` folder.
4. Install the packages:

   ```bash
   npm install
   ```

5. Copy `.env.example` to a new file named `.env`.
6. Open `.env` and replace `put_your_api_key_here` with your API key. Leave the key on your own computer. Don't share `.env` or upload it anywhere.
7. Start Blue:

   ```bash
   npm start
   ```

8. Open http://localhost:3000 in Chrome.
9. Type a message or click **Talk to Blue** and allow microphone access when prompted.

## Personalize Blue

Edit the personality instructions in `server.mjs`, in the `instructions` text. For example, change the personality to be more sarcastic (but kind), more retro-computer-like, more calm, or more silly.

Use **Blue's memory notes** in the app to save a few non-sensitive details or preferences. Notes are stored in that browser on that device using local storage and are sent to the AI on each message. Clearing browser site data can remove them. Don't save passwords, home addresses, private contact details, or secrets.

## Troubleshooting

- **API key missing:** Check that the file is named `.env` (not `.env.example`) and restart the server.
- **API/model error:** Check that your API account has access and that `OPENAI_MODEL` names a model available to your account. You can change the model in `.env`.
- **Microphone won't work:** Check browser microphone permissions. Speech recognition availability varies by browser and may require internet access. Typing still works without the microphone.
- **Port is already in use:** Change `PORT=3000` in `.env` to `PORT=3001`, restart, and open `http://localhost:3001`.
- **Stop the app:** In the terminal, press `Ctrl+C`.

## Privacy and limits

- This is a starter project, not a public production service. It has no user accounts or server-side authentication.
- Don't expose the server publicly as-is; add authentication and rate limits before hosting it online.
- Browser speech recognition may use your browser provider's online speech service.
- The app sends your message, recent chat context, and memory notes to the AI API to generate replies.
